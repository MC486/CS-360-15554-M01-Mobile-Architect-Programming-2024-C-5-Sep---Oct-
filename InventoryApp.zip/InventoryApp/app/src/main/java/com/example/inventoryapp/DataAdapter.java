package com.example.inventoryapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.DataViewHolder> {

    private final ArrayList<Item> itemList;
    private final Context context;
    private final DatabaseHelper databaseHelper; // Add DatabaseHelper instance
    private int lowStockThreshold; // Define a threshold for low stock

    // Modify the constructor to accept DatabaseHelper
    public DataAdapter(Context context, ArrayList<Item> itemList, DatabaseHelper databaseHelper, int lowStockThreshold) {
        this.context = context;
        this.itemList = itemList;
        this.databaseHelper = databaseHelper; // Initialize DatabaseHelper
        this.lowStockThreshold = lowStockThreshold; // Initialize low stock threshold
    }

    @NonNull
    @Override
    public DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_grid, parent, false);
        return new DataViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DataViewHolder holder, int position) {
        Item item = itemList.get(position);
        holder.itemNameTextView.setText(item.getName());
        holder.itemQuantityTextView.setText(String.valueOf(item.getQuantity()));
        holder.itemStatusTextView.setText(item.getQuantity() > 0 ? "In Stock" : "Out of Stock");
        holder.itemDateTextView.setText(item.getDate());

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, EditDataActivity.class);
            intent.putExtra("itemId", item.getId());
            intent.putExtra("itemName", item.getName());
            intent.putExtra("itemQuantity", item.getQuantity());
            intent.putExtra("itemDate", item.getDate());
            context.startActivity(intent);
        });

        holder.deleteButton.setOnClickListener(v -> {
            itemList.remove(position);
            notifyItemRemoved(position);
            databaseHelper.deleteItem(item.getId());
        });

        holder.plusButton.setOnClickListener(v -> {
            int newQuantity = item.getQuantity() + 1;
            item.setQuantity(newQuantity);
            holder.itemQuantityTextView.setText(String.valueOf(newQuantity));
            holder.itemStatusTextView.setText(newQuantity > 0 ? "In Stock" : "Out of Stock");

            databaseHelper.updateItem(item.getId(), item.getName(), newQuantity, item.getDate());
            notifyItemChanged(position);
        });

        holder.minusButton.setOnClickListener(v -> {
            int newQuantity = item.getQuantity() - 1;
            if (newQuantity < 0) {
                newQuantity = 0;
            }
            item.setQuantity(newQuantity);
            holder.itemQuantityTextView.setText(String.valueOf(newQuantity));
            holder.itemStatusTextView.setText(newQuantity > 0 ? "In Stock" : "Out of Stock");

            databaseHelper.updateItem(item.getId(), item.getName(), newQuantity, item.getDate());
            notifyItemChanged(position);

            // Check if stock is low after decrement
            if (newQuantity == 0) {
                sendZeroStockNotification(item);
            } else if (newQuantity <= lowStockThreshold && newQuantity > 0) {
                sendLowStockNotification(item);
            }
        });
    }

    private void sendLowStockNotification(Item item) {
        String phoneNumber = databaseHelper.getSettings().getPhoneNumber(); // Fetch the phone number from settings
        String message = "Warning: Low stock for item " + item.getName() + ". Quantity: " + item.getQuantity();

        SMSHelper.sendSMSNotification(context, phoneNumber, message);
        Toast.makeText(context, "Low stock notification sent for " + item.getName(), Toast.LENGTH_SHORT).show();
    }

    private void sendZeroStockNotification(Item item) {
        String phoneNumber = databaseHelper.getSettings().getPhoneNumber(); // Fetch the phone number from settings
        String message = "Alert: Item " + item.getName() + " is out of stock!";

        SMSHelper.sendSMSNotification(context, phoneNumber, message);
        Toast.makeText(context, "Zero stock notification sent for " + item.getName(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public static class DataViewHolder extends RecyclerView.ViewHolder {
        TextView itemNameTextView;
        TextView itemQuantityTextView;
        TextView itemStatusTextView;
        TextView itemDateTextView;
        Button deleteButton;
        Button plusButton;
        Button minusButton;

        public DataViewHolder(@NonNull View itemView) {
            super(itemView);
            itemNameTextView = itemView.findViewById(R.id.itemNameTextView);
            itemQuantityTextView = itemView.findViewById(R.id.itemQuantityTextView);
            itemStatusTextView = itemView.findViewById(R.id.itemStatusTextView);
            itemDateTextView = itemView.findViewById(R.id.itemDateTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            plusButton = itemView.findViewById(R.id.plusButton);
            minusButton = itemView.findViewById(R.id.minusButton);
        }
    }
}
