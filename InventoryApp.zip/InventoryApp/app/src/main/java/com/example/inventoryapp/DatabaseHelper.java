// DatabaseHelper.java
package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventoryApp.db";
    private static final int DATABASE_VERSION = 2; // Incremented version to trigger upgrade

    // User Table
    private static final String USER_TABLE = "users";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // Item Table
    private static final String ITEM_TABLE = "ItemTable";
    private static final String COL_ID = "id";
    private static final String COL_NAME = "itemName";
    private static final String COL_QUANTITY = "quantity";
    private static final String COL_DATE = "itemDate";

    // Settings Table
    private static final String SETTINGS_TABLE = "Settings";
    private static final String COL_PHONE_NUMBER = "phoneNumber";
    private static final String COL_THRESHOLD = "threshold";
    private static final String COL_SMS_ENABLED = "smsEnabled";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the users table
        String createUserTable = "CREATE TABLE " + USER_TABLE + " (" +
                COL_USERNAME + " TEXT PRIMARY KEY, " +
                COL_PASSWORD + " TEXT)";
        db.execSQL(createUserTable);

        // Create the items table
        String createItemTable = "CREATE TABLE " + ITEM_TABLE + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NAME + " TEXT, " +
                COL_QUANTITY + " INTEGER, " +
                COL_DATE + " TEXT)";
        db.execSQL(createItemTable);

        // Create the settings table
        String createSettingsTable = "CREATE TABLE " + SETTINGS_TABLE + " (" +
                COL_PHONE_NUMBER + " TEXT, " +
                COL_THRESHOLD + " INTEGER, " +
                COL_SMS_ENABLED + " INTEGER)";
        db.execSQL(createSettingsTable);

        // Insert default items into the items table
        insertDefaultItems(db);

        // Insert default settings into the settings table
        insertDefaultSettings(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // Upgrade logic for version 2: add the settings table
            String createSettingsTable = "CREATE TABLE IF NOT EXISTS " + SETTINGS_TABLE + " (" +
                    COL_PHONE_NUMBER + " TEXT, " +
                    COL_THRESHOLD + " INTEGER, " +
                    COL_SMS_ENABLED + " INTEGER)";
            db.execSQL(createSettingsTable);

            // Insert default settings if the table is newly created
            Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + SETTINGS_TABLE, null);
            if (cursor.moveToFirst() && cursor.getInt(0) == 0) {
                insertDefaultSettings(db);
            }
            cursor.close();
        }
    }

    // Method to insert default items into the items table
    private void insertDefaultItems(SQLiteDatabase db) {
        addItemForInitialization(db, "Apples", 10, "10/20/24");
        addItemForInitialization(db, "Bananas", 18, "10/10/24");
        addItemForInitialization(db, "Elephant", 1, "10/01/24");
    }

    // Overloaded method for adding items during initialization
    private boolean addItemForInitialization(SQLiteDatabase db, String name, int quantity, String date) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_NAME, name);
        contentValues.put(COL_QUANTITY, quantity);
        contentValues.put(COL_DATE, date);

        long result = db.insert(ITEM_TABLE, null, contentValues);
        return result != -1;
    }

    // Method to insert default settings
    private void insertDefaultSettings(SQLiteDatabase db) {
        ContentValues defaultSettings = new ContentValues();
        defaultSettings.put(COL_PHONE_NUMBER, "5554");
        defaultSettings.put(COL_THRESHOLD, 5);
        defaultSettings.put(COL_SMS_ENABLED, 1);
        db.insert(SETTINGS_TABLE, null, defaultSettings);
    }

    // User-related methods
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_USERNAME, username);
        contentValues.put(COL_PASSWORD, password);

        long result = db.insert(USER_TABLE, null, contentValues);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(USER_TABLE,
                new String[]{COL_USERNAME},
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null);
        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }

    // Item-related methods
    public boolean addItem(String name, int quantity, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_NAME, name);
        contentValues.put(COL_QUANTITY, quantity);
        contentValues.put(COL_DATE, date);

        long result = db.insert(ITEM_TABLE, null, contentValues);
        return result != -1;
    }

    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + ITEM_TABLE, null);
    }

    public boolean deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(ITEM_TABLE, COL_ID + "=?", new String[]{String.valueOf(id)});
        return result > 0;
    }

    public boolean updateItem(int id, String name, int quantity, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_NAME, name);
        contentValues.put(COL_QUANTITY, quantity);
        contentValues.put(COL_DATE, date);

        int result = db.update(ITEM_TABLE, contentValues, COL_ID + "=?", new String[]{String.valueOf(id)});
        return result > 0;
    }

    // Settings-related methods
    public Settings getSettings() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(SETTINGS_TABLE, null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            String phoneNumber = cursor.getString(cursor.getColumnIndexOrThrow(COL_PHONE_NUMBER));
            int threshold = cursor.getInt(cursor.getColumnIndexOrThrow(COL_THRESHOLD));
            boolean smsEnabled = cursor.getInt(cursor.getColumnIndexOrThrow(COL_SMS_ENABLED)) == 1;
            cursor.close();
            return new Settings(phoneNumber, threshold, smsEnabled);
        }
        cursor.close();
        return null;
    }

    public void saveSettings(String phoneNumber, int threshold, boolean smsEnabled) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_PHONE_NUMBER, phoneNumber);
        contentValues.put(COL_THRESHOLD, threshold);
        contentValues.put(COL_SMS_ENABLED, smsEnabled ? 1 : 0);

        int updatedRows = db.update(SETTINGS_TABLE, contentValues, null, null);
        if (updatedRows == 0) {
            db.insert(SETTINGS_TABLE, null, contentValues);
        }
        Log.d("DatabaseHelper", "Saving settings: Phone: " + phoneNumber + ", Threshold: " + threshold + ", SMS Enabled: " + smsEnabled);

    }
}
