// MainActivity.java
package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;
    private static final String TAG = "MainActivity";
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);
        EditText username = findViewById(R.id.editTextText);
        EditText password = findViewById(R.id.editTextTextPassword);
        Button loginButton = findViewById(R.id.button);
        Button signUpButton = findViewById(R.id.button2);

        // Login button action
        loginButton.setOnClickListener(v -> {
            String user = username.getText().toString();
            String pass = password.getText().toString();
            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            } else if (databaseHelper.checkUser(user, pass)) {
                // Check for SMS permission before proceeding
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    // Permission already granted, proceed to DataDisplayActivity
                    Log.d(TAG, "SMS permission already granted.");
                    proceedToDataDisplay();
                } else {
                    // Request SMS permission
                    Log.d(TAG, "Requesting SMS permission.");
                    requestSmsPermission();
                }
            } else {
                Toast.makeText(MainActivity.this, "Invalid login credentials", Toast.LENGTH_SHORT).show();
            }
        });

        // Sign up button action
        signUpButton.setOnClickListener(v -> {
            // Navigate to the RegisterActivity
            Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }

    private void requestSmsPermission() {
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error requesting SMS permission: " + e.getMessage());
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission granted", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "SMS Permission granted. Proceeding to DataDisplayActivity.");
                proceedToDataDisplay(); // Proceed to DataDisplayActivity if permission is granted
            } else {
                Toast.makeText(this, "SMS Permission denied. SMS functionality will be disabled.", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "SMS Permission denied. Proceeding to DataDisplayActivity.");
                proceedToDataDisplay(); // Proceed to DataDisplayActivity even if permission is denied
            }
        } else {
            Log.e(TAG, "Unexpected request code: " + requestCode);
        }
    }

    private void proceedToDataDisplay() {
        try {
            Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class);
            startActivity(intent);
            Log.d(TAG, "Navigated to DataDisplayActivity.");
            // Temporarily comment out finish() to avoid closing the activity
            // finish();
        } catch (Exception e) {
            Log.e(TAG, "Error proceeding to DataDisplayActivity: " + e.getMessage());
        }
    }
}
