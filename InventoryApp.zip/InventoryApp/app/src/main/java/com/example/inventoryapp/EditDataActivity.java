// EditDataActivity.java
package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class EditDataActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private int itemId;

    // EditDataActivity.java
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_data);

        databaseHelper = new DatabaseHelper(this);

        EditText itemNameEditText = findViewById(R.id.itemNameEditText);
        EditText itemQuantityEditText = findViewById(R.id.itemQuantityEditText);
        EditText itemDateEditText = findViewById(R.id.itemDateEditText);
        Button updateDataButton = findViewById(R.id.updateDataButton);

        // Get the item data from the Intent
        Intent intent = getIntent();
        itemId = intent.getIntExtra("itemId", -1);
        String itemName = intent.getStringExtra("itemName");
        int itemQuantity = intent.getIntExtra("itemQuantity", 0);
        String itemDate = intent.getStringExtra("itemDate");

        // Set the initial values
        itemNameEditText.setText(itemName);
        itemQuantityEditText.setText(String.valueOf(itemQuantity));
        itemDateEditText.setText(itemDate);

        updateDataButton.setOnClickListener(v -> {
            String newItemName = itemNameEditText.getText().toString().trim();
            String newItemQuantityStr = itemQuantityEditText.getText().toString().trim();
            String newItemDate = itemDateEditText.getText().toString().trim();

            if (newItemName.isEmpty() || newItemQuantityStr.isEmpty() || newItemDate.isEmpty()) {
                Toast.makeText(EditDataActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                int newItemQuantity = Integer.parseInt(newItemQuantityStr);
                boolean isUpdated = databaseHelper.updateItem(itemId, newItemName, newItemQuantity, newItemDate);
                if (isUpdated) {
                    Toast.makeText(EditDataActivity.this, "Item updated successfully", Toast.LENGTH_SHORT).show();
                    Intent dataDisplayIntent = new Intent(EditDataActivity.this, DataDisplayActivity.class);
                    startActivity(dataDisplayIntent);
                    finish();
                } else {
                    Toast.makeText(EditDataActivity.this, "Failed to update item", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}
