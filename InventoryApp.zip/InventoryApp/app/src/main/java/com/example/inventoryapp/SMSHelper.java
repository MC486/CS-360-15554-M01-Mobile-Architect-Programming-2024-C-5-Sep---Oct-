package com.example.inventoryapp;

import android.content.Context;
import android.os.Build;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;

public class SMSHelper {

    private static final String TAG = "SMSHelper";

    public static void sendSMSNotification(Context context, String phoneNumber, String message) {
        try {
            SmsManager smsManager;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // For Android 12 and above
                smsManager = context.getSystemService(SmsManager.class);
            } else {
                // For older Android versions
                smsManager = SmsManager.getDefault();
            }

            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(context, "SMS Sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e(TAG, "Failed to send SMS", e);
            Toast.makeText(context, "Failed to send SMS", Toast.LENGTH_SHORT).show();
        }
    }
}
