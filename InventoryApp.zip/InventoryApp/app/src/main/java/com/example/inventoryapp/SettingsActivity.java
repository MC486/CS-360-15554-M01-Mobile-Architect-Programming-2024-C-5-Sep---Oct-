// SettingsActivity.java
package com.example.inventoryapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private EditText phoneNumberEditText;
    private EditText thresholdEditText;
    private Switch smsNotificationSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        databaseHelper = new DatabaseHelper(this);
        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        thresholdEditText = findViewById(R.id.thresholdEditText);
        smsNotificationSwitch = findViewById(R.id.smsNotificationSwitch);
        Button saveButton = findViewById(R.id.saveButton);

        // Load the current settings
        loadSettings();

        // Disable the SMS notification switch to make it non-interactive
        smsNotificationSwitch.setEnabled(false); // Disable the switch

        // Save button action to save settings in the database
        saveButton.setOnClickListener(v -> {
            String phoneNumber = phoneNumberEditText.getText().toString().trim();
            String thresholdStr = thresholdEditText.getText().toString().trim();
            boolean smsEnabled = smsNotificationSwitch.isChecked();

            // Validate the input fields
            if (phoneNumber.isEmpty() || thresholdStr.isEmpty()) {
                Toast.makeText(SettingsActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                try {
                    int threshold = Integer.parseInt(thresholdStr);
                    databaseHelper.saveSettings(phoneNumber, threshold, smsEnabled);
                    Toast.makeText(SettingsActivity.this, "Settings saved", Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK); // Set result code to OK
                    finish(); // Close SettingsActivity
                } catch (NumberFormatException e) {
                    Toast.makeText(SettingsActivity.this, "Invalid threshold value", Toast.LENGTH_SHORT).show();
                }
            }

        });
    }

    // Load settings from the database to populate the UI fields
    private void loadSettings() {
        Settings settings = databaseHelper.getSettings();
        if (settings != null) {
            // Display current settings in the UI
            phoneNumberEditText.setText(settings.getPhoneNumber());
            thresholdEditText.setText(String.valueOf(settings.getThreshold()));
            smsNotificationSwitch.setChecked(settings.isSmsEnabled());
        } else {
            // Use default settings if none are found
            phoneNumberEditText.setText("5554");
            thresholdEditText.setText("5"); // Default threshold
            smsNotificationSwitch.setChecked(true); // Enable SMS by default
        }
    }
}
