package com.example.inventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class DataDisplayActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private RecyclerView recyclerView;
    private DataAdapter adapter;
    private ArrayList<Item> itemList;
    private ArrayList<Item> filteredList;
    private EditText itemNameEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        databaseHelper = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.dataRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        itemNameEditText = findViewById(R.id.itemNameEditText);
        itemList = new ArrayList<>();
        filteredList = new ArrayList<>();

        // Retrieve the current threshold from settings
        int currentThreshold = databaseHelper.getSettings() != null ? databaseHelper.getSettings().getThreshold() : 5;

        // Initialize the adapter with context, item list, DatabaseHelper, and current threshold
        adapter = new DataAdapter(this, filteredList, databaseHelper, currentThreshold);
        recyclerView.setAdapter(adapter);

        // Load data from the database
        loadData();

        Button addDataButton = findViewById(R.id.addDataButton);
        addDataButton.setOnClickListener(v -> {
            Intent intent = new Intent(DataDisplayActivity.this, AddDataActivity.class);
            startActivity(intent);
        });

        // Settings button action
        ImageButton settingsButton = findViewById(R.id.settingsButton);
        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(DataDisplayActivity.this, SettingsActivity.class);
            startActivityForResult(intent, 1); // Start for result
        });

        // Add text watcher to filter list based on user input
        itemNameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void loadData() {
        itemList.clear();
        Cursor cursor = databaseHelper.getAllItems();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("itemName"));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("itemDate"));
                itemList.add(new Item(id, name, quantity, date));
            } while (cursor.moveToNext());
        }
        cursor.close();

        // Update filteredList
        filteredList.clear();
        filteredList.addAll(itemList);
        adapter.notifyDataSetChanged();
    }

    private void filter(String text) {
        filteredList.clear();
        if (text.isEmpty()) {
            filteredList.addAll(itemList);
        } else {
            for (Item item : itemList) {
                if (item.getName().toLowerCase().contains(text.toLowerCase())) {
                    filteredList.add(item);
                }
            }
        }
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData(); // Reload data when returning to the activity
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) { // Check if it's from SettingsActivity
            if (resultCode == RESULT_OK) { // Check if settings were saved successfully
                loadData(); // Refresh data
            }
        }
    }
}
