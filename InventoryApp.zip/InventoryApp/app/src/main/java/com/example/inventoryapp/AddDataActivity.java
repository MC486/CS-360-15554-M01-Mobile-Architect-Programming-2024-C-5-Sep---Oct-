// AddDataActivity.java
package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddDataActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_data);

        databaseHelper = new DatabaseHelper(this);

        EditText itemNameEditText = findViewById(R.id.itemNameEditText);
        EditText itemQuantityEditText = findViewById(R.id.itemQuantityEditText);
        EditText itemDateEditText = findViewById(R.id.itemDateEditText);
        Button submitDataButton = findViewById(R.id.submitDataButton);

        submitDataButton.setOnClickListener(v -> {
            String itemName = itemNameEditText.getText().toString().trim();
            String itemQuantityStr = itemQuantityEditText.getText().toString().trim();
            String itemDate = itemDateEditText.getText().toString().trim();

            if (itemName.isEmpty() || itemQuantityStr.isEmpty() || itemDate.isEmpty()) {
                Toast.makeText(AddDataActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                int itemQuantity = Integer.parseInt(itemQuantityStr);
                boolean isInserted = databaseHelper.addItem(itemName, itemQuantity, itemDate);
                if (isInserted) {
                    Toast.makeText(AddDataActivity.this, "Item added successfully", Toast.LENGTH_SHORT).show();
                    // Return to the DataDisplayActivity
                    Intent intent = new Intent(AddDataActivity.this, DataDisplayActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(AddDataActivity.this, "Failed to add item", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
