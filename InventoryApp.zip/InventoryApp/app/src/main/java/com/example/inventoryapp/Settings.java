// Settings.java
package com.example.inventoryapp;

public class Settings {
    private final String phoneNumber;
    private final int threshold;
    private final boolean smsEnabled;

    public Settings(String phoneNumber, int threshold, boolean smsEnabled) {
        this.phoneNumber = phoneNumber;
        this.threshold = threshold;
        this.smsEnabled = smsEnabled;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public int getThreshold() {
        return threshold;
    }

    public boolean isSmsEnabled() {
        return smsEnabled;
    }
}
