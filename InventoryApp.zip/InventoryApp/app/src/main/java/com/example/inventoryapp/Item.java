// Item.java
package com.example.inventoryapp;

public class Item {
    private int id;  // Represents the item ID
    private String name;
    private int quantity;
    private String date;

    public Item(int id, String name, int quantity, String date) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.date = date;
    }

    // Getter and setter methods for ID
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    // Getter and setter methods for name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter and setter methods for quantity
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Getter and setter methods for date
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
